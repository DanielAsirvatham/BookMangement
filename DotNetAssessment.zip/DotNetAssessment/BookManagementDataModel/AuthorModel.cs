﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookManagementDataModel
{
    [Table("Author", Schema = "BookManagement")]
    public class AuthorModel
    {
        [Key]
        public int AuthorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string? Qualification { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? pincode { get; set; }
    }
}
