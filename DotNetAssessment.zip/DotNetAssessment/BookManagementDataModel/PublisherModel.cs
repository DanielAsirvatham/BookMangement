﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookManagementDataModel
{
    [Table("Publisher", Schema = "BookManagement")]
    public class PublisherModel
    {
        [Key]
        public int publisherId { get; set; }
        public string publisherName { get; set; }
        public string NoofBookspublished { get; set; }
        public string Yearofpulishing { get; set; }
    }
}
