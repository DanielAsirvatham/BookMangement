﻿using BookManagementDataModel;
using BookManagementService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement.Controllers
{

    [Route("api/[BookController]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookService _bookService;
        readonly ILogger _logger;

        public BooksController(IBookService bookService, ILogger logger)
        {
            _bookService = bookService;
            _logger = logger;
        }

        [HttpGet("GetMethod")]
        public string Get()
        {
            return "This is first method";
        }

        public async Task<HttpResponseMessage> GetBooksByPublisherSortedList()
        {
            try
            {
                _logger.LogInformation("BooksController:GetBooksByPublisherSortedList method is calling");
                var bookList = await _bookService.GetBooksByPublisherSortedList();

                return new HttpResponseMessage
                {
                    Content = new StringContent(bookList.ToString(), Encoding.UTF8, "application/text")
                };
            }
            catch (System.Exception ex)
            {
                _logger.LogError("BooksController:GetBooksByPublisherSortedList method {0}", ex);
                return new HttpResponseMessage
                {
                    Content = new StringContent("Error occurs", Encoding.UTF8, "application/json")
                };

            }
        }

        public async Task<HttpResponseMessage> GetBooksByAuthorSortedList()
        {
            try
            {
                _logger.LogInformation("BooksController:GetBooksByAuthorSortedList method is calling");
                var bookList = await _bookService.GetBooksByAuthorSortedList();

                return new HttpResponseMessage
                {
                    Content = new StringContent(bookList.ToString(), Encoding.UTF8, "application/text")
                };
            }
            catch (System.Exception ex)
            {
                _logger.LogError("BooksController:GetBooksByAuthorSortedList method {0}", ex);
                return new HttpResponseMessage
                {
                    Content = new StringContent("Error occurs", Encoding.UTF8, "application/json")
                };
            }
        }

        public async Task<HttpResponseMessage> GetTotalPriceOfAllBook()
        {
            try
            {
                _logger.LogInformation("BooksController:GetTotalPriceOfAllBook method is calling");
                var bookList = await _bookService.GetTotalPriceOfAllBook();

                return new HttpResponseMessage
                {
                    Content = new StringContent(bookList.ToString(), Encoding.UTF8, "application/text")
                };
            }
            catch (System.Exception ex)
            {
                _logger.LogError("BooksController:GetTotalPriceOfAllBook method {0}", ex);
                return new HttpResponseMessage
                {
                    Content = new StringContent("Error occurs", Encoding.UTF8, "application/json")
                };
            }
        }

        public async Task<HttpResponseMessage> InsertAuthors(List<AuthorModel> authorModel)
        {
            try
            {
                _logger.LogInformation("BooksController:InsertAuthors method is calling");
                var bookList = await _bookService.InsertAuthors(authorModel);

                return new HttpResponseMessage
                {
                    Content = new StringContent(bookList.ToString(), Encoding.UTF8, "application/text")
                };
            }
            catch (System.Exception ex)
            {
                _logger.LogError("BooksController:InsertAuthors method {0}", ex);
                return new HttpResponseMessage
                {
                    Content = new StringContent("Error occurs", Encoding.UTF8, "application/json")
                };
            }
        }
    }
}
