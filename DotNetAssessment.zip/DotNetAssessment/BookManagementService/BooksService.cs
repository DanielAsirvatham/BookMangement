﻿using BookManagementDataAccess;
using BookManagementDataModel;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace BookManagementService
{
    public interface IBookService
    {
        public Task<List<BooksModel>> GetBooksByPublisherSortedList();
        public Task<List<BooksModel>> GetBooksByAuthorSortedList();
        public Task<decimal> GetTotalPriceOfAllBook();
        public Task<int> InsertAuthors(List<AuthorModel> authorModel);
        public Task<List<PublisherModel>> InsertPublisher(List<PublisherModel> publisherModel);
    }
    public class BooksService : IBookService
    {
        readonly ILogger _logger;
        readonly IBooksQuery _booksQuery;

        public BooksService(ILogger logger, IBooksQuery booksQuery)
        {
            _logger = logger;
            _booksQuery = booksQuery;
        }

        public async Task<List<BooksModel>> GetBooksByPublisherSortedList()
        {
            var bookPublisher = await _booksQuery.GetBooksByPublisherSortedList();
            return bookPublisher;
            
        }
        public async Task<List<BooksModel>> GetBooksByAuthorSortedList()
        {
            var bookAuthor = await _booksQuery.GetBooksByAuthorSortedList();
            return bookAuthor;
        }

        public async Task<decimal> GetTotalPriceOfAllBook()
        {
            var totalPriceOfAllBook = await _booksQuery.GetTotalPriceOfAllBook();
            _logger.LogInformation("GetTotalPriceOfAllBook method totalPriceOfAllBook {0}", totalPriceOfAllBook);
            return totalPriceOfAllBook;
        }

        public async Task<int> InsertAuthors(List<AuthorModel> authorModel)
        {
            List<AuthorModel> entitiesToAdd = new List<AuthorModel>();
            foreach (var authDetails in authorModel)
            {
                var auth = new AuthorModel()
                {
                    AuthorId = authDetails.AuthorId,
                    FirstName = authDetails.FirstName,
                    LastName = authDetails.LastName,
                    Qualification = authDetails.Qualification,
                    Address1 = authDetails.Address1,
                    Address2 = authDetails.Address2,
                    pincode = authDetails.pincode
                };
                entitiesToAdd.Add(auth);
            }

            var author = await _booksQuery.InsertAuthors(authorModel);
            return author;
        }

        public async Task<List<PublisherModel>> InsertPublisher(List<PublisherModel> publisherModel)
        {
            List<PublisherModel> publisherList = new List<PublisherModel>();
            foreach (var publisher in publisherModel)
            {
                var pub = new PublisherModel()
                {
                    publisherName = publisher.publisherName,
                    NoofBookspublished = publisher.NoofBookspublished,
                    Yearofpulishing = publisher.Yearofpulishing,
                };
                publisherList.Add(pub);
            }

            var author = await _booksQuery.InsertPublisher(publisherModel);
            return publisherList;
        }
    }
}
