﻿using Microsoft.Extensions.Configuration;

namespace BookManagementDataAccess
{
    public class Configuration
    {

        public Configuration(BooksSetting _booksSetting)
        {
            BooksSettings = _booksSetting;
        }

        public BooksSetting BooksSettings { get; set; }

    }
    public class BooksSetting
    {
        readonly IConfiguration _configuration;
        readonly string _settingName = "BooksSetting";

        public BooksSetting(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public string ConnectionString()
        {
            return _configuration[_settingName + ":ConnectionString"];
        }
    }
}
