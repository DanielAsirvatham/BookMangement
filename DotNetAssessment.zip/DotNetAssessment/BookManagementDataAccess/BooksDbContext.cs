﻿using BookManagementDataModel;
using Microsoft.EntityFrameworkCore;

namespace BookManagementDataAccess
{
    public class BooksDbContext : DbContext
    {
        readonly Configuration _configuration;

        public BooksDbContext(Configuration configuration)
        {
            _configuration = configuration;
        }

        public DbSet<BooksModel> BooksModel { get; set; }
        public DbSet<AuthorModel> AuthorModel { get; set; }
        public DbSet<PublisherModel> PublisherModel { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
               _configuration.BooksSettings.ConnectionString());
        }
    }
}
