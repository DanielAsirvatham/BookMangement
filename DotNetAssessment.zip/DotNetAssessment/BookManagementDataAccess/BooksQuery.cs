﻿using BookManagementDataModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookManagementDataAccess
{
    public interface IBooksQuery
    {
        public Task<List<BooksModel>> GetBooksByPublisherSortedList();
        public Task<List<BooksModel>> GetBooksByAuthorSortedList();
        public Task<decimal> GetTotalPriceOfAllBook();
        public Task<int> InsertAuthors(List<AuthorModel> authorModel);
        public Task<List<PublisherModel>> InsertPublisher(List<PublisherModel> publisherModel);
    }

    public class BooksQuery : IBooksQuery
    {
        readonly Configuration _configuration;
        readonly BooksDbContext _dbContext;
        readonly ILogger _logger;

        public BooksQuery(Configuration configuration, BooksDbContext dbContext, ILogger logger)
        {
            _configuration = configuration;
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<List<BooksModel>> GetBooksByPublisherSortedList()
        {
            _logger.LogInformation("GetBooksByPublisherSortedList method is started");
            var result = await _dbContext
            .Set<BooksModel>()
            .FromSqlRaw("exec [dbo].[GetBooksByPublisherSortedList]").ToListAsync();
            _logger.LogInformation("GetBooksByPublisherSortedList method is end");
            return result;
        }

        public async Task<List<BooksModel>> GetBooksByAuthorSortedList()
        {
            _logger.LogInformation("GetBooksByAuthorSortedList method is started");
            var result = await _dbContext
            .Set<BooksModel>()
            .FromSqlRaw("exec [dbo].[GetBooksByAuthorSortedList]").ToListAsync();
            _logger.LogInformation("GetBooksByAuthorSortedList method is end");
            return result;
        }

        public async Task<decimal> GetTotalPriceOfAllBook()
        {
            _logger.LogInformation("GetTotalPriceOfAllBook method is started");
            var result = await _dbContext
            .Set<object>()
            .FromSqlRaw("exec [dbo].[GetTotalPriceOfAllBook]").FirstOrDefaultAsync();
            _logger.LogInformation("GetTotalPriceOfAllBook method is end");
            return (decimal)result;
        }

        public async Task<int> InsertAuthors(List<AuthorModel> authorModel)
        {
            _dbContext.AuthorModel.AddRange(authorModel);
            var result = await _dbContext.SaveChangesAsync();
            return result;
        }

        public async Task<List<PublisherModel>> InsertPublisher(List<PublisherModel> publisherModel)
        {
            var result = await _dbContext
            .Set<PublisherModel>()
            .FromSqlRaw("exec [dbo].[InsertPublisher]", publisherModel).ToListAsync();
            return result;
        }
    }
}
